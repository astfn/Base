function as(a) {
  if (a) {
    console.log("ashunteh函数依赖as函数");
  } else {
    console.log("as函数加载完毕了");
  }
}
