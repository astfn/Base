function ashunte() {
  as(1);
  console.log("ashunte函数");
}
