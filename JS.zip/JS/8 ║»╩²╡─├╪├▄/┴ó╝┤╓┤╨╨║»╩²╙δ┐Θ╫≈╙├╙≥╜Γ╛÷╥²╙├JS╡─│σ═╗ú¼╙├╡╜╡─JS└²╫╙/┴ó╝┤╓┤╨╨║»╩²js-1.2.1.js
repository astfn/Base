// JavaScript Document
(function(window){
	
	function aa(){
	console.log('这是js-1.2.1的aa函数');
    }
      function bb(){
	console.log('这是js-1.2.1的bb函数')
   }
	
	window.js121={aa,bb};
	
})(window)
/*
     立即执行函数内部，是一个独立的作用域，从而防止外部同名函数的污染
	 
	 
     立即执行函数把整个 全局 作为变量， 然后再把立即执行函数 内部的各个函数 压到全局里面。


*/