// JavaScript Document
function aa(){
	console.log('这是js-1.1.2的aa函数');
}
function bb(){
	console.log('这是js-1.1.2的bb函数');
}