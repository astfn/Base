// JavaScript Document
function aa(){
	console.log('这是js-1.1.1的aa函数');
}
function bb(){
	console.log('这是js-1.1.1的bb函数')
}