// JavaScript Document
{
	
let aa=function(){
	console.log('这是js-1.3.1的aa函数');
}
let bb=function (){
	console.log('这是js-1.3.1的bb函数')
}

    window.js131={aa,bb};


}
/*

    利用 let的块级作用域，来防止外部的污染，
	在把各个函数追加在window全局对象中。


*/