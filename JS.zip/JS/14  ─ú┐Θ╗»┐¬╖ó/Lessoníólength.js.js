// JavaScript Document
import {obj} from "./Lesson.js";
let sum=obj.get().length;
export{sum}