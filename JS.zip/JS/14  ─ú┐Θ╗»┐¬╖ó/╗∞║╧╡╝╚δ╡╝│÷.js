// JavaScript Document
class User{
	static show(){return "User的静态方法show()~"}
}

let site="ashuntefannao.com";
export {User as default,site} 