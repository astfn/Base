// JavaScript Document
let site="ASHUN站点。";
let url="m2的url:ASHUNTEFANNAO.com";
export {site,url};