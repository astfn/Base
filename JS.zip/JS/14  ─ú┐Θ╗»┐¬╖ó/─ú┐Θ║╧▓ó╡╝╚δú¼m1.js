// JavaScript Document
class User{
	constructor(name){
		this.name=name;
	}
	static show(){
		console.log("这是User类的show()静态方法")
	}
}

let url="m1的url:ashun.com";
export{User as default,url}