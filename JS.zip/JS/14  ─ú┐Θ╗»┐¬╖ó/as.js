// JavaScript Document
let site="ashun.com";
console.log('调用了as.js');