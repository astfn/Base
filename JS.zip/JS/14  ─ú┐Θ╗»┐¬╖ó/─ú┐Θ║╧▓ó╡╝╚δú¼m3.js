// JavaScript Document
import * as m1 from './模块合并导入，m1.js';
import * as m2 from './模块合并导入，m2.js';

export{m1,m2}