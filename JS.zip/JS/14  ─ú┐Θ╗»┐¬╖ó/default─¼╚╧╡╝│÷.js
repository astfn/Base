// JavaScript Document
 class User{
	 constructor(name){
		 this.name=name;
	 }
	 show(){
		 return `尊敬的 ${this.name} 您好！`;
	 }
 }

let  use=new User("阿顺");
let a=use.show();
// export default a 
 export{a as default}
