// JavaScript Document
let site="as1.js"
export{site}