// JavaScript Document
class Lesson{
	constructor(data){
		this.data=data;
	}
	get(){
		return this.data
	}
}

  let data=[
	  {cat:'Js',price:100},
	  {cat:'VUE.JS',price:90},
  ];
 let obj= new Lesson(data);
 console.log("只解析一次");
let site="ashuntefannao.com";
	export{obj,Lesson,site}