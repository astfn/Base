// JavaScript Document
let url="ashunte.com";
console.log('调用了ashunte.js');
//console.log(site)
//console.log(as)访问的是全局的as