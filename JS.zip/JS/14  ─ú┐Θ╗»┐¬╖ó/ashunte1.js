// JavaScript Document
import {site} from "./as1.js";
console.log("通过ashunte1.js调用了:"+site);