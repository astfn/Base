// JavaScript Document
let site="ashunte.com";
class User{
	constructor(name){
		this.name=name;
	}
	show(){return `用户名是:${this.name}`}
};
let a=new User("阿顺");
let b=a.show();

export {site as url,User as user,b as as}